package com.br.library.pweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryPwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
