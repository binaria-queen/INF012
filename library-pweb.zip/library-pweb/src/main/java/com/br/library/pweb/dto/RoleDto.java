package com.br.library.pweb.dto;

import com.br.library.pweb.entities.Role;

public record RoleDto(Long id, String role) {
	
	public RoleDto(Role role) {
		this(role.getId(), role.getRole());
	}

}