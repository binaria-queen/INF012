package com.br.library.pweb.enums;

public enum Role {
	
	USER, ADMIN
}
