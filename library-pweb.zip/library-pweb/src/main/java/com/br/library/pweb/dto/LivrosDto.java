package com.br.library.pweb.dto;

public class LivrosDto {

}
