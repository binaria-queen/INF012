package com.br.library.pweb.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.br.library.pweb.dto.CriaTokenDto;
import com.br.library.pweb.dto.LivroDto;
import com.br.library.pweb.dto.LoginRequestDto;
import com.br.library.pweb.service.LibraryService;

@RequestMapping("/api/v1")
@RestController
public class LibraryController {
	
	private LibraryService service;
	
	public LibraryController(LibraryService service) {
		this.service = service;
	}

	@PostMapping("/auth/login")
	public ResponseEntity<CriaTokenDto> logar(@RequestBody LoginRequestDto login){
		return null;
	}
	
	@GetMapping("/livros")
	public String listarLivros(){
		return "ok";
	}
	
	@PostMapping("/livros")
	public ResponseEntity<LivroDto> adicionarLivro(@RequestBody LivroDto novoLivro){
		return null;
	}
	
	@PutMapping("/livros/{id}")
	public ResponseEntity<LivroDto> atualizarLivro(@RequestBody LivroDto novoLivro, @PathVariable Long id){
		return null;
	}
	
	@DeleteMapping("/livros/{id}") 
	public ResponseEntity<LivroDto> excluirLivro(@PathVariable Long id) {
		return null;
		
	}
	
	
}
