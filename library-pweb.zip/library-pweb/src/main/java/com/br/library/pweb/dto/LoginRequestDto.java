package com.br.library.pweb.dto;

public record LoginRequestDto (
	
	String username,
	String password
	) {
}
