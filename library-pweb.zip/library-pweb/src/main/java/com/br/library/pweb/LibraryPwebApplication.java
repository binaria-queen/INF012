package com.br.library.pweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryPwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryPwebApplication.class, args);
	}

}
