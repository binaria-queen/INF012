package com.br.library.pweb.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.br.library.pweb.dto.CriaTokenDto;	
import com.br.library.pweb.dto.LivroDto;
import com.br.library.pweb.dto.LivrosDto;
import com.br.library.pweb.dto.LoginRequestDto;
import com.br.library.pweb.repository.LibraryRepository;

@Service
public class LibraryService {
	
	private LibraryRepository repository;
	
	public LibraryService (LibraryRepository repository) {
		this.repository = repository;
	}

	public ResponseEntity<CriaTokenDto> logar(LoginRequestDto login){
		repository.logar(login);
		return null;
	}
	
	public List<LivrosDto> listarLivros(){
		repository.listarLivros();
		return null;
	}
	
	public ResponseEntity<LivroDto> adicionarLivro(LivroDto novoLivro){
		repository.adicionarLivro(novoLivro);
		return null;
	}
	
	public ResponseEntity<LivroDto> atualizarLivro(LivroDto novoLivro, Long id){
		repository.atualizarLivro(novoLivro, id);
		return null;
	}
	
	public ResponseEntity<LivroDto> excluirLivro(Long id) {
		repository.excluirLivro(id);
		return null;
		
	}
}
