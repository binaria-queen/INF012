package com.br.library.pweb.repository;

import org.springframework.stereotype.Repository;

import com.br.library.pweb.dto.LivroDto;
import com.br.library.pweb.dto.LoginRequestDto;

@Repository
public class LibraryRepository {

	public void logar(LoginRequestDto login) {
		// TODO Auto-generated method stub
		
	}

	public void listarLivros() {
		// TODO Auto-generated method stub
		
	}

	public void adicionarLivro(LivroDto novoLivro) {
		// TODO Auto-generated method stub
		
	}

	public void atualizarLivro(LivroDto novoLivro, Long id) {
		// TODO Auto-generated method stub
		
	}

	public void excluirLivro(Long id) {
		// TODO Auto-generated method stub
		
	}

	public Object findByLogin(String login) {
		// TODO Auto-generated method stub
		return null;
	}

}
